module CocoaPodsTrunk
  VERSION = '1.3.1'.freeze
end
