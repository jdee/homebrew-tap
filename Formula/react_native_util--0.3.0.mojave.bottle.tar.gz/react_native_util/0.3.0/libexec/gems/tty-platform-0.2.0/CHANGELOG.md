# Change log

## [v0.2.0] - 2018-12-02

### Changed
* Change to Ruby >= 2.0


## [v0.1.0] - 2015-05-16

* Initial implementation and release

[v0.2.0]: https://github.com/piotrmurach/tty-platform/compare/v0.1.0...v0.2.0
[v0.1.0]: https://github.com/piotrmurach/tty-platform/compare/v0.1.0
