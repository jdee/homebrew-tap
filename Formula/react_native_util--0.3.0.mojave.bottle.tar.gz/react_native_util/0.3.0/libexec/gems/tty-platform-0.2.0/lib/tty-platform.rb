require_relative 'tty/platform'
