# frozen_string_literal: true

module TTY
  class Platform
    VERSION = "0.2.0"
  end # Platform
end # TTY
