class FuzzyMatch
  VERSION = '2.0.4'
end
