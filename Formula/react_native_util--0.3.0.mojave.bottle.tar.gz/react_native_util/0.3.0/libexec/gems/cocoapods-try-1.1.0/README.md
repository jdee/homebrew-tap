# Cocoapods try

[![Build Status](https://img.shields.io/travis/CocoaPods/cocoapods-try/master.svg?style=flat)](https://travis-ci.org/CocoaPods/cocoapods-try)
[![Coverage](https://img.shields.io/codeclimate/coverage/github/CocoaPods/cocoapods-try.svg?style=flat)](https://codeclimate.com/github/CocoaPods/cocoapods-try)
[![Code Climate](https://img.shields.io/codeclimate/github/CocoaPods/cocoapods-try.svg?style=flat)](https://codeclimate.com/github/CocoaPods/cocoapods-try)

CocoaPods plugin which allows to quickly try the demo project of a Pod.

![](http://i.imgur.com/xxWNUrg.gif)

## Usage

    $ pod try POD_NAME

## Installation

    $ gem install cocoapods-try


